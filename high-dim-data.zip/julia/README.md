# Julia WDI 2022 Prototype

This prototype runs the WDI 2022 clustering and exploratory factor-analysis workflow in Julia.

Run from this directory:

```bash
nix develop --command julia prototype.jl
```

Outputs are written to `outputs/`.
