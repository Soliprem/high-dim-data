using CSV
using Clustering
using DataFrames
using LinearAlgebra
using MultivariateStats
ENV["GKSwstype"] = "100"
using Plots
using Random
using Statistics
using StatsBase

const DATA_PATH = "../Exam data sets 25-26/WDI 2022/WDI_World_2022.csv"
const OUT_DIR = "outputs"
const SEED = 42
const N_CLUSTERS = 4
const N_FACTORS = 2

const ID_COLUMNS = ["country", "iso3c", "region", "income", "year"]

const CLUSTERING_FEATURES = [
    "BG.GSR.NFSV.GD.ZS",
    "BM.GSR.INSF.ZS",
    "BM.GSR.TRAN.ZS",
    "BM.GSR.TRVL.ZS",
    "BM.KLT.DINV.WD.GD.ZS",
    "BX.GSR.INSF.ZS",
    "BX.GSR.TRAN.ZS",
    "BX.GSR.TRVL.ZS",
    "BX.KLT.DINV.WD.GD.ZS",
    "DT.DOD.DSTC.XP.ZS",
    "DT.ODA.ODAT.MP.ZS",
    "DT.TDS.DECT.EX.ZS",
    "DT.TDS.DPPF.XP.ZS",
    "DT.TDS.DPPG.XP.ZS",
    "FP.CPI.TOTL.ZG",
    "GC.NFN.TOTL.GD.ZS",
    "GC.TAX.GSRV.RV.ZS",
    "GC.TAX.GSRV.VA.ZS",
    "GC.XPN.GSRV.ZS",
    "IQ.SPI.PIL2",
    "LP.LPI.LOGS.XQ",
    "NE.EXP.GNFS.KD.ZG",
    "NE.EXP.GNFS.ZS",
    "NE.IMP.GNFS.KD.ZG",
    "NE.IMP.GNFS.ZS",
    "NE.RSB.GNFS.ZS",
    "NV.SRV.EMPL.KD",
    "NV.SRV.TOTL.KD.ZG",
    "NV.SRV.TOTL.ZS",
    "NY.GDP.DEFL.KD.ZG",
]

const FACTOR_FEATURES = [
    "BX.KLT.DINV.WD.GD.ZS",
    "BM.KLT.DINV.WD.GD.ZS",
    "BG.GSR.NFSV.GD.ZS",
    "NE.EXP.GNFS.ZS",
    "NE.IMP.GNFS.ZS",
    "NE.RSB.GNFS.ZS",
    "NV.SRV.TOTL.ZS",
    "NV.SRV.EMPL.KD",
    "LP.LPI.LOGS.XQ",
    "IQ.SPI.PIL2",
    "FP.CPI.TOTL.ZG",
]

function validate_data(df::DataFrame)
    required = unique(vcat(ID_COLUMNS, CLUSTERING_FEATURES, FACTOR_FEATURES))
    missing_columns = setdiff(required, String.(names(df)))
    if !isempty(missing_columns)
        error("Missing required columns: $(missing_columns)")
    end
    if nrow(df) != 217
        error("Expected 217 rows, got $(nrow(df))")
    end
    years = sort(unique(skipmissing(df.year)))
    if years != [2022]
        error("Expected only year 2022, got $(years)")
    end
end

function feature_matrix(df::DataFrame, features::Vector{String})
    x = Matrix{Float64}(undef, nrow(df), length(features))
    for (j, feature) in enumerate(features)
        column = df[!, Symbol(feature)]
        for i in eachindex(column)
            if ismissing(column[i])
                x[i, j] = NaN
            else
                value = tryparse(Float64, string(column[i]))
                if value === nothing || !isfinite(value)
                    x[i, j] = NaN
                else
                    x[i, j] = value
                end
            end
        end
        observed = x[.!isnan.(x[:, j]), j]
        if isempty(observed)
            error("Feature has no numeric values: $(feature)")
        end
        x[isnan.(x[:, j]), j] .= median(observed)
        if any(.!isfinite.(x[:, j]))
            error("Feature contains non-finite values after imputation: $(feature)")
        end
    end

    service_worker_idx = findfirst(==("NV.SRV.EMPL.KD"), features)
    if service_worker_idx !== nothing
        if minimum(x[:, service_worker_idx]) <= -1
            error("Cannot log1p NV.SRV.EMPL.KD because it contains values <= -1")
        end
        x[:, service_worker_idx] = log1p.(x[:, service_worker_idx])
    end

    for j in axes(x, 2)
        lower = quantile(x[:, j], 0.01)
        upper = quantile(x[:, j], 0.99)
        x[:, j] = clamp.(x[:, j], lower, upper)
    end

    scaled = similar(x)
    for j in axes(x, 2)
        μ = mean(x[:, j])
        σ = std(x[:, j])
        if σ == 0
            error("Feature has zero standard deviation: $(features[j])")
        end
        scaled[:, j] = (x[:, j] .- μ) ./ σ
    end

    return x, scaled
end

function varimax(loadings::AbstractMatrix{<:Real}; normalize::Bool=true, maxiter::Int=1000, tol::Float64=1e-6)
    matrix = Matrix{Float64}(loadings)
    scale = ones(size(matrix, 1))
    if normalize
        scale = sqrt.(sum(matrix .^ 2; dims=2))[:, 1]
        scale[scale .== 0.0] .= 1.0
        matrix = matrix ./ scale
    end

    n_rows, n_cols = size(matrix)
    rotation = Matrix{Float64}(I, n_cols, n_cols)
    previous = 0.0

    for _ in 1:maxiter
        projected = matrix * rotation
        basis = matrix' * (projected .^ 3 .- (projected * Diagonal(diag(projected' * projected))) ./ n_rows)
        svd_result = svd(basis)
        rotation = svd_result.U * svd_result.Vt
        current = sum(svd_result.S)
        if previous != 0.0 && current / previous < 1.0 + tol
            break
        end
        previous = current
    end

    rotated = matrix * rotation
    if normalize
        rotated = rotated .* scale
    end
    return rotated
end

function factor_scores_from_loadings(x_scaled::Matrix{Float64}, loadings::Matrix{Float64})
    coefficients = pinv(loadings' * loadings) * loadings'
    return x_scaled * coefficients'
end

function cluster_profiles(raw_features::Matrix{Float64}, labels::Vector{Int}, features::Vector{String})
    rows = DataFrame(cluster=sort(unique(labels)))
    for (j, feature) in enumerate(features)
        rows[!, Symbol(feature)] = [
            mean(raw_features[labels .== cluster, j])
            for cluster in rows.cluster
        ]
    end
    return rows
end

function income_crosstab(incomes, labels::Vector{Int})
    income_levels = sort(unique(String.(incomes)))
    cluster_levels = sort(unique(labels))
    out = DataFrame(cluster=cluster_levels)
    for income in income_levels
        out[!, Symbol(income)] = [
            count((labels .== cluster) .& (String.(incomes) .== income))
            for cluster in cluster_levels
        ]
    end
    return out
end

function mean_silhouette(x::Matrix{Float64}, labels::Vector{Int})
    n = size(x, 1)
    unique_labels = sort(unique(labels))
    values = zeros(n)

    for i in 1:n
        own_label = labels[i]
        same_cluster = findall(labels .== own_label)
        if length(same_cluster) <= 1
            values[i] = 0.0
            continue
        end

        a = mean([
            norm(view(x, i, :) .- view(x, j, :))
            for j in same_cluster
            if j != i
        ])

        b = minimum([
            mean([
                norm(view(x, i, :) .- view(x, j, :))
                for j in findall(labels .== other_label)
            ])
            for other_label in unique_labels
            if other_label != own_label
        ])

        values[i] = (b - a) / max(a, b)
    end

    return mean(values)
end

function write_cluster_outputs(df::DataFrame, raw_features::Matrix{Float64}, x_scaled::Matrix{Float64}, labels::Vector{Int})
    assignments = select(df, Symbol.(ID_COLUMNS))
    assignments.cluster = labels
    CSV.write(joinpath(OUT_DIR, "cluster_assignments.csv"), assignments)

    CSV.write(
        joinpath(OUT_DIR, "cluster_profiles.csv"),
        cluster_profiles(raw_features, labels, CLUSTERING_FEATURES),
    )
    CSV.write(
        joinpath(OUT_DIR, "cluster_income_crosstab.csv"),
        income_crosstab(df.income, labels),
    )

    pca_model = fit(PCA, x_scaled'; maxoutdim=2)
    pca_points = predict(pca_model, x_scaled')'
    scatter(
        pca_points[:, 1],
        pca_points[:, 2];
        group=labels,
        xlabel="PC1",
        ylabel="PC2",
        title="WDI 2022 Countries by K-means Cluster",
        legend=:outerright,
        markersize=4,
    )
    savefig(joinpath(OUT_DIR, "pca_clusters.png"))
end

function write_factor_outputs(df::DataFrame, x_scaled::Matrix{Float64})
    model = fit(FactorAnalysis, x_scaled'; maxoutdim=N_FACTORS)
    rotated_loadings = varimax(loadings(model))

    loading_df = DataFrame(feature=FACTOR_FEATURES)
    for i in 1:N_FACTORS
        loading_df[!, Symbol("factor_$(i)")] = rotated_loadings[:, i]
    end
    CSV.write(joinpath(OUT_DIR, "factor_loadings_varimax.csv"), loading_df)

    communalities = vec(sum(rotated_loadings .^ 2; dims=2))
    communality_df = DataFrame(
        feature=FACTOR_FEATURES,
        communality=communalities,
        uniqueness=1.0 .- communalities,
    )
    CSV.write(joinpath(OUT_DIR, "factor_communalities.csv"), communality_df)

    scores = factor_scores_from_loadings(x_scaled, rotated_loadings)
    score_df = select(df, [:country, :iso3c, :region, :income])
    for i in 1:N_FACTORS
        score_df[!, Symbol("factor_$(i)")] = scores[:, i]
    end
    CSV.write(joinpath(OUT_DIR, "factor_scores.csv"), score_df)

    heatmap(
        1:N_FACTORS,
        1:length(FACTOR_FEATURES),
        rotated_loadings;
        yticks=(1:length(FACTOR_FEATURES), FACTOR_FEATURES),
        xticks=(1:N_FACTORS, ["factor_$(i)" for i in 1:N_FACTORS]),
        color=:balance,
        title="Varimax-Rotated Factor Loadings",
        size=(850, 650),
        margin=8Plots.mm,
    )
    savefig(joinpath(OUT_DIR, "factor_loadings_heatmap.png"))
end

function main()
    mkpath(OUT_DIR)
    df = CSV.read(DATA_PATH, DataFrame)
    validate_data(df)

    raw_cluster_features, x_cluster = feature_matrix(df, CLUSTERING_FEATURES)
    Random.seed!(SEED)
    result = kmeans(x_cluster', N_CLUSTERS; maxiter=300, display=:none)
    labels = assignments(result)
    silhouette = mean_silhouette(x_cluster, labels)

    write_cluster_outputs(df, raw_cluster_features, x_cluster, labels)

    _, x_factor = feature_matrix(df, FACTOR_FEATURES)
    write_factor_outputs(df, x_factor)

    println("Rows: $(nrow(df))")
    println("Clusters: $(N_CLUSTERS)")
    println("Silhouette score: $(round(silhouette; digits=4))")
    println("Outputs written to $(abspath(OUT_DIR))")
end

main()
