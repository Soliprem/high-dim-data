from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import FactorAnalysis, PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


DATA_PATH = Path("../Exam data sets 25-26/WDI 2022/WDI_World_2022.csv")
OUT_DIR = Path("outputs")
SEED = 42
N_CLUSTERS = 4
N_FACTORS = 2

ID_COLUMNS = ["country", "iso3c", "region", "income", "year"]

CLUSTERING_FEATURES = [
    "BG.GSR.NFSV.GD.ZS",
    "BM.GSR.INSF.ZS",
    "BM.GSR.TRAN.ZS",
    "BM.GSR.TRVL.ZS",
    "BM.KLT.DINV.WD.GD.ZS",
    "BX.GSR.INSF.ZS",
    "BX.GSR.TRAN.ZS",
    "BX.GSR.TRVL.ZS",
    "BX.KLT.DINV.WD.GD.ZS",
    "DT.DOD.DSTC.XP.ZS",
    "DT.ODA.ODAT.MP.ZS",
    "DT.TDS.DECT.EX.ZS",
    "DT.TDS.DPPF.XP.ZS",
    "DT.TDS.DPPG.XP.ZS",
    "FP.CPI.TOTL.ZG",
    "GC.NFN.TOTL.GD.ZS",
    "GC.TAX.GSRV.RV.ZS",
    "GC.TAX.GSRV.VA.ZS",
    "GC.XPN.GSRV.ZS",
    "IQ.SPI.PIL2",
    "LP.LPI.LOGS.XQ",
    "NE.EXP.GNFS.KD.ZG",
    "NE.EXP.GNFS.ZS",
    "NE.IMP.GNFS.KD.ZG",
    "NE.IMP.GNFS.ZS",
    "NE.RSB.GNFS.ZS",
    "NV.SRV.EMPL.KD",
    "NV.SRV.TOTL.KD.ZG",
    "NV.SRV.TOTL.ZS",
    "NY.GDP.DEFL.KD.ZG",
]

FACTOR_FEATURES = [
    "BX.KLT.DINV.WD.GD.ZS",
    "BM.KLT.DINV.WD.GD.ZS",
    "BG.GSR.NFSV.GD.ZS",
    "NE.EXP.GNFS.ZS",
    "NE.IMP.GNFS.ZS",
    "NE.RSB.GNFS.ZS",
    "NV.SRV.TOTL.ZS",
    "NV.SRV.EMPL.KD",
    "LP.LPI.LOGS.XQ",
    "IQ.SPI.PIL2",
    "FP.CPI.TOTL.ZG",
]


def validate_data(df: pd.DataFrame) -> None:
    required = set(ID_COLUMNS + CLUSTERING_FEATURES + FACTOR_FEATURES)
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if len(df) != 217:
        raise ValueError(f"Expected 217 rows, got {len(df)}")
    years = sorted(df["year"].dropna().unique().tolist())
    if years != [2022]:
        raise ValueError(f"Expected only year 2022, got {years}")


def winsorize_columns(values: pd.DataFrame) -> pd.DataFrame:
    lower = values.quantile(0.01)
    upper = values.quantile(0.99)
    return values.clip(lower=lower, upper=upper, axis=1)


def preprocess_features(df: pd.DataFrame, features: list[str]) -> tuple[pd.DataFrame, np.ndarray]:
    values = df.loc[:, features].apply(pd.to_numeric, errors="coerce")
    entirely_missing = values.columns[values.notna().sum() == 0].tolist()
    if entirely_missing:
        raise ValueError(f"Features have no numeric values: {entirely_missing}")
    values = values.fillna(values.median(numeric_only=True))

    values = values.astype(float)
    if "NV.SRV.EMPL.KD" in values.columns:
        min_value = values["NV.SRV.EMPL.KD"].min()
        if min_value <= -1:
            raise ValueError("Cannot log1p NV.SRV.EMPL.KD because it contains values <= -1")
        values["NV.SRV.EMPL.KD"] = np.log1p(values["NV.SRV.EMPL.KD"])

    values = winsorize_columns(values)
    if not np.isfinite(values.to_numpy()).all():
        raise ValueError("Feature matrix contains non-finite values")

    scaled = StandardScaler().fit_transform(values)
    return values, scaled


def varimax(
    loadings: np.ndarray,
    *,
    normalize: bool = True,
    max_iter: int = 1000,
    tol: float = 1e-6,
) -> np.ndarray:
    matrix = np.array(loadings, dtype=float, copy=True)
    if normalize:
        scale = np.sqrt((matrix**2).sum(axis=1))
        scale[scale == 0.0] = 1.0
        matrix = matrix / scale[:, None]

    n_rows, n_cols = matrix.shape
    rotation = np.eye(n_cols)
    previous = 0.0

    for _ in range(max_iter):
        projected = matrix @ rotation
        basis = matrix.T @ (
            projected**3
            - (projected @ np.diag(np.diag(projected.T @ projected))) / n_rows
        )
        u, singular_values, vh = np.linalg.svd(basis, full_matrices=False)
        rotation = u @ vh
        current = singular_values.sum()
        if previous != 0.0 and current / previous < 1.0 + tol:
            break
        previous = current

    rotated = matrix @ rotation
    if normalize:
        rotated = rotated * scale[:, None]
    return rotated


def factor_scores_from_loadings(x_scaled: np.ndarray, loadings: np.ndarray) -> np.ndarray:
    coefficients = np.linalg.pinv(loadings.T @ loadings) @ loadings.T
    return x_scaled @ coefficients.T


def write_cluster_outputs(
    df: pd.DataFrame,
    raw_features: pd.DataFrame,
    x_scaled: np.ndarray,
    labels: np.ndarray,
) -> None:
    assignments = df.loc[:, ID_COLUMNS].copy()
    assignments["cluster"] = labels
    assignments.to_csv(OUT_DIR / "cluster_assignments.csv", index=False)

    cluster_profiles = raw_features.copy()
    cluster_profiles["cluster"] = labels
    cluster_profiles.groupby("cluster").mean().sort_index().to_csv(
        OUT_DIR / "cluster_profiles.csv"
    )

    pd.crosstab(assignments["cluster"], assignments["income"]).to_csv(
        OUT_DIR / "cluster_income_crosstab.csv"
    )

    pca_points = PCA(n_components=2, random_state=SEED).fit_transform(x_scaled)
    plot_df = pd.DataFrame(
        {
            "PC1": pca_points[:, 0],
            "PC2": pca_points[:, 1],
            "cluster": labels.astype(str),
            "income": assignments["income"],
            "country": assignments["country"],
        }
    )
    plt.figure(figsize=(9, 6))
    sns.scatterplot(data=plot_df, x="PC1", y="PC2", hue="cluster", style="income", s=55)
    plt.title("WDI 2022 Countries by K-means Cluster")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "pca_clusters.png", dpi=180)
    plt.close()


def write_factor_outputs(df: pd.DataFrame, x_scaled: np.ndarray) -> None:
    model = FactorAnalysis(n_components=N_FACTORS, rotation=None, random_state=SEED)
    model.fit(x_scaled)
    loadings = model.components_.T
    rotated_loadings = varimax(loadings)

    loading_df = pd.DataFrame(
        rotated_loadings,
        index=FACTOR_FEATURES,
        columns=[f"factor_{i}" for i in range(1, N_FACTORS + 1)],
    )
    loading_df.to_csv(OUT_DIR / "factor_loadings_varimax.csv")

    communalities = (rotated_loadings**2).sum(axis=1)
    communality_df = pd.DataFrame(
        {
            "feature": FACTOR_FEATURES,
            "communality": communalities,
            "uniqueness": 1.0 - communalities,
        }
    )
    communality_df.to_csv(OUT_DIR / "factor_communalities.csv", index=False)

    scores = factor_scores_from_loadings(x_scaled, rotated_loadings)
    score_df = df.loc[:, ["country", "iso3c", "region", "income"]].copy()
    for i in range(N_FACTORS):
        score_df[f"factor_{i + 1}"] = scores[:, i]
    score_df.to_csv(OUT_DIR / "factor_scores.csv", index=False)

    plt.figure(figsize=(8, 6))
    sns.heatmap(loading_df, annot=True, fmt=".2f", cmap="vlag", center=0.0)
    plt.title("Varimax-Rotated Factor Loadings")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "factor_loadings_heatmap.png", dpi=180)
    plt.close()


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA_PATH)
    validate_data(df)

    raw_cluster_features, x_cluster = preprocess_features(df, CLUSTERING_FEATURES)
    model = KMeans(n_clusters=N_CLUSTERS, random_state=SEED, n_init=50)
    labels = model.fit_predict(x_cluster) + 1
    score = silhouette_score(x_cluster, labels)

    write_cluster_outputs(df, raw_cluster_features, x_cluster, labels)

    _, x_factor = preprocess_features(df, FACTOR_FEATURES)
    write_factor_outputs(df, x_factor)

    print(f"Rows: {len(df)}")
    print(f"Clusters: {N_CLUSTERS}")
    print(f"Silhouette score: {score:.4f}")
    print(f"Outputs written to {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
