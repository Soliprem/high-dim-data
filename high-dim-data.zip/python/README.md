# Python WDI 2022 Prototype

This prototype runs the WDI 2022 clustering and exploratory factor-analysis workflow in Python.

Run from this directory:

```bash
nix develop --command python prototype.py
```

Outputs are written to `outputs/`.
